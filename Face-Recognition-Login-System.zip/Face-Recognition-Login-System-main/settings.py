# Color and Font settings (Do not change anything here)

# Color options
color1 = "white"
color2 = "sky blue"
color3 = "black"
color4 = "gray45"
color5 = "green"
# Font options
font1 = "times new roman"
font2 = "helvetica"
font3 = "kokila"
font4 = "Courier"
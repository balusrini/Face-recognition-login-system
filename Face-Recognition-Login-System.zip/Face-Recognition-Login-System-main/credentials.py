# Credentials (You must put your own credentials here)
host = 'localhost'
username = 'Your Username Here'
password = 'Your Password Here'

database = 'employee_management'
